npm init
npm start