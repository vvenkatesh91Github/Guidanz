import Chart from "./chart";
import Image from "./image";

export const DRAGGABLES = [Chart, Image];