import React from 'react';

const Chart = () => {
    return (
    <div className="component">
        Chart Component
    </div>
    );
}

export default Chart();
