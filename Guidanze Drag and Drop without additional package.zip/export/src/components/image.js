import React from 'react';

const Image = () => {
    return (
    <div className="component">
        Image Component
    </div>
    );
}

export default Image();
