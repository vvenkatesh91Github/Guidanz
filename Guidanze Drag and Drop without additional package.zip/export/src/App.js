import React from 'react';
import { DRAGGABLES } from "./components/draggableComponents";
import './App.css';

class App extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            original : DRAGGABLES,
            dragged : []
        };
        this.dragElement = React.createRef();
        this.cursorPositionWithDragElement = {top: 0, left: 0};
        this.zIndex = 0;
    }

    onClick = index => {
        var dragged = this.state.dragged;
        var copy = dragged[index];
        if(copy.zIndex !== this.zIndex || this.zIndex === 0) {
            copy.zIndex = ++this.zIndex;
            dragged[index] = copy;
            this.setState({dragged: dragged});
        }
    };
    
    onDragOver = (event) => {
        event.preventDefault();
    }
    
    onDragStart = (event, index, isExisting) => {
        event.dataTransfer.setData("index", index);
        event.dataTransfer.setData("isExisting", isExisting);
        var rect = event.target.getBoundingClientRect();
        var x = event.clientX - rect.left;
        var y = event.clientY - rect.top;
        var zIndex = this.zIndex;
        if(isExisting === "existing" && (this.state.dragged[index].zIndex !== this.zIndex || this.zIndex === 0))
            zIndex = ++this.zIndex;
        this.cursorPositionWithDragElement = {top: x, left: y, zIndex: zIndex};
    }

    onDrop = (event) => {
        let index = event.dataTransfer.getData("index");
        let isExisting = event.dataTransfer.getData("isExisting");
        let dragged = this.state.dragged;
        let copy = {};
        copy.left = event.screenX-200-this.cursorPositionWithDragElement.top;
        copy.top = event.screenY-100-this.cursorPositionWithDragElement.left;
        copy.zIndex = this.cursorPositionWithDragElement.zIndex;
        if(isExisting === "existing") {
            copy.component = this.state.dragged[index].component;
            dragged[index] = copy;
        }
        else {
            copy.component = this.state.original[index];
            dragged.push(copy);
        }
        this.setState({dragged: dragged});
    }

    render() {
        return (
            <>
                <div className="draggable">
                    {
                        /*
                        Can keep the draggable component of any form.
                        Like having a snapshot image property in the component and showing the shapshot in this section.
                        I'm just keeping the component itself with different dimension for time sake.
                        */
                        DRAGGABLES.map((Component, index) => {
                            return (
                                <div key={index} draggable
                                onDragStart={event => this.onDragStart(event, index)}
                                ref={this.dragElement}
                                >
                                    {Component}
                                </div>
                            );
                        }) 
                    }
                </div>
                <div className="droppable" 
                    onDragOver={event => this.onDragOver(event)}
                    onDrop={event => this.onDrop(event)}
                >
                    {
                        this.state.dragged.map((Copy, index) => {
                            return  <section draggable
                                        key={index}
                                        style={{"top": Copy.top, "left": Copy.left, "zIndex": Copy.zIndex}}
                                        onDragStart={event => this.onDragStart(event, index, "existing")}
                                        onClick={() => this.onClick(index)}
                                        ref={this.dragElement}
                                    >
                                        {Copy.component}
                                    </section>
                        })
                    }
                </div>
            </>
        );
    }
}

export default App;
